﻿using System;
using System.Collections.Generic;


namespace CasinoAssessment
{
    class Program
    {
        static string[] playerCards = new string[52]; // create a new string array named playerCards, which we will store our cards in.
        static string hitOrStay = ""; // create a string variable named hitOrStay to ask to hit or stay.
        static int total = 0, count = 1, dealerTotal = 0;// create three integer variables named total, which is for our total, count, which is our variable to get an index in our array (we increase to hold multiple cards), and dealerTotal, which is, obviously, the dealer's total.
        static Random cardRandomizer = new Random(); // create a new instance of Random called cardRandomizer so we can randomize our cards and the dealer's total
        static Random suitRendomizer = new Random();

        static void Main(string[] args)
        {
            Start();
        }
        static string Deal()
        {
            string Card = "";
            List<string> suit = new List<string>();
            suit.Add("Diamond");
            suit.Add("Hearts");
            suit.Add("Spades");
            suit.Add("Clubs");
         //   Random randNum = new Random();
            int aRandomPos = suitRendomizer.Next(suit.Count);//Returns a nonnegative random number less than the specified maximum (firstNames.Count).

            string currName = suit[aRandomPos];

            int cards = cardRandomizer.Next(1, 14);
            switch (cards)
            {
                case 1:
                    Card = "a Two of "+ currName; total += 2;
                    break;
                case 2:
                    Card = "a Three of " + currName; total += 3;
                    break;
                case 3:
                    Card = "a Four of  " + currName; total += 4;
                    break;
                case 4:
                    Card = "a Five of " + currName; total += 5;
                    break;
                case 5:
                    Card = "a Six of " + currName; total += 6;
                    break;
                case 6:
                    Card = "a Seven of " + currName; ; total += 7;
                    break;
                case 7:
                    Card = "a Eight of " + currName; ; total += 8;
                    break;
                case 8:
                    Card = "a Nine of " + currName; ; total += 9;
                    break;
                case 9:
                    Card = "a Ten of " + currName; ; total += 10;
                    break;
                case 10:
                    Card = "a Jack of " + currName; ; total += 10;
                    break;
                case 11:
                    Card = "a Queen of " + currName; ; total += 10;
                    break;
                case 12:
                    Card = "a King of " + currName; ; total += 10;
                    break;
                case 13:
                    Card = "a Ace of " + currName; ; total += 1;
                    break;
                default:
                    Card = "a 2 of " + currName; ; total += 2;

                    break;
            }
            return Card;
        }
        static void Start()
        {
            dealerTotal = cardRandomizer.Next(15, 22); // A random number between 15 and 21 for the dealer's number
            playerCards[0] = Deal(); // assign the index 0 (our first index) of playerCards[] to the returned value of Deal(); this is our first card
            playerCards[1] = Deal(); // assign the index 1 (our second index) of playerCards[] to the returned value of Deal(); this is our second card
            do

            {
                Console.WriteLine("Welcome to Cassino Cards! You were dealt " + playerCards[0] + " and " + playerCards[1] + ". \nYour total is " + total + ".\nWould you like to hit or stay?");

                hitOrStay = Console.ReadLine().ToLower();
            } while (!hitOrStay.Equals("hit") && !hitOrStay.Equals("stay")); // tell the user what numbers they were dealed, and then ask them to hit or stay. Do this until they enter a correct value.

            Game(); // Call the gam 12

        }
        static void Game()

        {

            if (hitOrStay.Equals("hit")) // we asked the user to hit or stay, and if they chose to hit..
            {

                Hit(); // call the method hit
            }
            else if (hitOrStay.Equals("stay")) // if they chose to stay..
            {
                if (total > dealerTotal && total <= 21) // if our total is greater than the dealer's total and less than 21..
                {
                    Console.WriteLine("\nCongrats! You won the game! The dealer's total was " + dealerTotal + ".\nWould you like to play again? y/n"); // tell the user the won, tell them the dealer's total, and ask them to play again
                    PlayAgain(); // Call the method 'PlayAgain()'.
                }
                else if (total < dealerTotal) // if our total is less than the dealer's..
                {
                    Console.WriteLine("\nSorry, you lost! The dealer's total was " + dealerTotal + ".\nWould you like to play again? y/n"); // tell the user they lost, tell them the dealer's total, and ask them to play again
                    PlayAgain(); // Call the method 'PlayAgain()'
                }
            }
        }
        static void Hit()
        {
            count += 1; // add one to count (count is where we get the number to index playerCards)
            playerCards[count] = Deal(); // Deal a card to our next avaliable index in playerCards 
            Console.WriteLine("\nYou were dealt " + playerCards[count] + ".\nYour new total is " + total + "."); // tell the user what they were dealt
            if (total.Equals(21)) // if their total is 21.. (Blackjack)
            {
                Console.WriteLine("\nYou won the Game! The dealer's total was " + dealerTotal + ".\nWould you like to play again?"); // Tell the user they got blackjack, tell them the dealer's total, and ask them to play again
                PlayAgain(); // Call the method PlayAgain()
            }
            else if (total > 21) // if their total is greater than 21.. (bust)
            {
                Console.WriteLine("\nYou busted, therefore you lost. Sorry. The dealer's total was " + dealerTotal + ".\nWould you like to play again? y/n"); // Tell the user they busted, tell them the dealer's total, and ask them to play again
                PlayAgain(); // Call the method PlayAgain()
            }
            else // otherwise.. (less than 21)
            {
                do
                {
                    Console.WriteLine("\nWould you like to hit or stay?");
                    hitOrStay = Console.ReadLine().ToLower();
                } while (!hitOrStay.Equals("hit") && !hitOrStay.Equals("stay")); // ask the user to hit or stay, and loop it until they give an acceptable answer
                Game(); // call the Game() method
            }
        }
        static void PlayAgain()
        {
            string playAgain = ""; // create a string to ask to play again
            do
            {
                playAgain = Console.ReadLine().ToLower();
            } while (!playAgain.Equals("y") && !playAgain.Equals("n")); // in the other methods, we asked if they wanted to play again, now we're just getting input and looping it until they give an acceptable answer
            if (playAgain.Equals("y")) // if they want to play again..
            {
                Console.WriteLine("\nPress enter to restart the game!"); // tell them to press enter to play again
                Console.ReadLine(); // get input (Enter)
                Console.Clear(); // Clear the Console
                dealerTotal = 0; // reset the dealer total
                count = 1; // reset the count
                total = 0; // reset our total
                Start(); // call the Start() method to restart the game
            }
            else if (playAgain.Equals("n")) // if they don't wanna play again..
            {
                Console.WriteLine("\nPress enter to close the Game."); // tell them to press enter to close the game
                Console.ReadLine(); // get input (Enter)
                Environment.Exit(0); // exit the Console with exit code 0
            }

        }

    }
    
}
